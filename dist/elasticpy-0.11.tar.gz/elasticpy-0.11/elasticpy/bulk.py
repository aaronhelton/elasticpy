#!/usr/bin/env python
'''
@author Luke Campbell <LCampbell@ASAScience.com>
@file bulk
@date 05/24/12 09:58
@description bulk support
'''

class ElasticBulk(object):
    def __init__(self):
        raise NotImplementedError('ElasticBulk is not yet implemented.')

